// ═══════════════════════════════════════════════════════════════════════
//  DS ELECTIONS 2026 — Google Apps Script Backend
//  Deploy this as a Web App (Execute as: Me, Who has access: Anyone)
//  Then copy the Web App URL into the voting app's SHEETS_URL setting.
// ═══════════════════════════════════════════════════════════════════════

const SHEET_NAME_VOTES   = 'Votes';
const SHEET_NAME_VOTERS  = 'Voters';
const SHEET_NAME_POLLS   = 'Polls';
const SHEET_NAME_MEMBERS = 'Members';
const SHEET_NAME_CFG     = 'Config';

// ── CORS helper ──────────────────────────────────────────────────────
function cors(output) {
  return output
    .setMimeType(ContentService.MimeType.JSON)
    .addHeader('Access-Control-Allow-Origin', '*')
    .addHeader('Access-Control-Allow-Methods', 'GET,POST')
    .addHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function ok(data) {
  return cors(ContentService.createTextOutput(JSON.stringify({ ok: true, data })));
}

function err(msg) {
  return cors(ContentService.createTextOutput(JSON.stringify({ ok: false, error: msg })));
}

// ── Sheet helpers ─────────────────────────────────────────────────────
function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    // Set headers per sheet
    const headers = {
      Votes:   ['timestamp','voterEmail','voterName','pollId','pollTitle','position','candidateId','candidateName'],
      Voters:  ['timestamp','id','name','email','year','registeredAt','device'],
      Polls:   ['timestamp','action','pollId','pollData'],
      Members: ['timestamp','action','memberId','memberData'],
      Config:  ['key','value','updatedAt']
    };
    if (headers[name]) sh.appendRow(headers[name]);
  }
  return sh;
}

function sheetToJSON(sheetName) {
  const sh = getSheet(sheetName);
  const rows = sh.getDataRange().getValues();
  if (rows.length < 2) return [];
  const headers = rows[0];
  return rows.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = row[i]; });
    return obj;
  });
}

// ── GET handler — read data ───────────────────────────────────────────
function doGet(e) {
  try {
    const action = (e.parameter && e.parameter.action) || 'ping';

    if (action === 'ping') return ok({ message: 'DS Elections API is live', ts: new Date().toISOString() });

    if (action === 'getAll') {
      // Return entire DB snapshot for a device to sync from
      const votes   = buildVoteMap();
      const voters  = sheetToJSON(SHEET_NAME_VOTERS);
      const polls   = getLatestPolls();
      const members = getLatestMembers();
      const cfg     = getConfig();
      return ok({ votes, voters, polls, members, cfg });
    }

    if (action === 'getVotes')   return ok(buildVoteMap());
    if (action === 'getVoters')  return ok(sheetToJSON(SHEET_NAME_VOTERS));
    if (action === 'getPolls')   return ok(getLatestPolls());
    if (action === 'getMembers') return ok(getLatestMembers());
    if (action === 'getConfig')  return ok(getConfig());

    return err('Unknown action: ' + action);
  } catch(ex) {
    return err(ex.toString());
  }
}

// ── POST handler — write data ─────────────────────────────────────────
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const { action } = body;

    if (action === 'submitVote')      return handleSubmitVote(body);
    if (action === 'registerVoter')   return handleRegisterVoter(body);
    if (action === 'savePolls')       return handleSavePolls(body);
    if (action === 'saveMembers')     return handleSaveMembers(body);
    if (action === 'saveConfig')      return handleSaveConfig(body);

    return err('Unknown action: ' + action);
  } catch(ex) {
    return err('POST error: ' + ex.toString());
  }
}

// ── Vote submission ───────────────────────────────────────────────────
function handleSubmitVote(body) {
  const { voter, pollId, pollTitle, choices, candidates } = body;
  if (!voter || !pollId || !choices) return err('Missing fields');

  // Duplicate check — one vote per voter per poll
  const existing = buildVoteMap();
  if (existing[pollId] && existing[pollId][voter.email]) {
    return ok({ alreadyVoted: true, message: 'This voter has already voted in this poll.' });
  }

  const sh = getSheet(SHEET_NAME_VOTES);
  const ts = new Date().toISOString();

  // Write one row per position chosen
  Object.entries(choices).forEach(([position, candidateId]) => {
    const candName = (candidates || []).find(c => c.id === candidateId)?.name || candidateId;
    sh.appendRow([ts, voter.email, voter.name, pollId, pollTitle || '', position, candidateId, candName]);
  });

  return ok({ recorded: true, rowsAdded: Object.keys(choices).length });
}

// ── Voter registration ────────────────────────────────────────────────
function handleRegisterVoter(body) {
  const { voter } = body;
  if (!voter || !voter.email) return err('Missing voter data');

  // Duplicate check
  const existing = sheetToJSON(SHEET_NAME_VOTERS);
  if (existing.find(v => v.email === voter.email)) {
    return ok({ alreadyRegistered: true });
  }

  getSheet(SHEET_NAME_VOTERS).appendRow([
    new Date().toISOString(),
    voter.id || 'v_' + Date.now(),
    voter.name,
    voter.email,
    voter.year || '',
    voter.reg || new Date().toISOString(),
    voter.device || ''
  ]);
  return ok({ registered: true });
}

// ── Polls CRUD ────────────────────────────────────────────────────────
function handleSavePolls(body) {
  const { polls } = body;
  if (!polls) return err('Missing polls array');
  const sh = getSheet(SHEET_NAME_POLLS);
  sh.appendRow([new Date().toISOString(), 'save', 'all', JSON.stringify(polls)]);
  return ok({ saved: true });
}

function getLatestPolls() {
  const rows = sheetToJSON(SHEET_NAME_POLLS);
  if (!rows.length) return [];
  // Last 'save all' row wins
  for (let i = rows.length - 1; i >= 0; i--) {
    if (rows[i].action === 'save') {
      try { return JSON.parse(rows[i].pollData); } catch(e) {}
    }
  }
  return [];
}

// ── Members CRUD ──────────────────────────────────────────────────────
function handleSaveMembers(body) {
  const { members } = body;
  if (!members) return err('Missing members array');
  const sh = getSheet(SHEET_NAME_MEMBERS);
  sh.appendRow([new Date().toISOString(), 'save', 'all', JSON.stringify(members)]);
  return ok({ saved: true });
}

function getLatestMembers() {
  const rows = sheetToJSON(SHEET_NAME_MEMBERS);
  if (!rows.length) return [];
  for (let i = rows.length - 1; i >= 0; i--) {
    if (rows[i].action === 'save') {
      try { return JSON.parse(rows[i].memberData); } catch(e) {}
    }
  }
  return [];
}

// ── Config ────────────────────────────────────────────────────────────
function handleSaveConfig(body) {
  const { cfg } = body;
  if (!cfg) return err('Missing cfg');
  const sh = getSheet(SHEET_NAME_CFG);
  // Upsert the 'main' config row
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === 'main') {
      sh.getRange(i + 1, 2).setValue(JSON.stringify(cfg));
      sh.getRange(i + 1, 3).setValue(new Date().toISOString());
      return ok({ saved: true });
    }
  }
  sh.appendRow(['main', JSON.stringify(cfg), new Date().toISOString()]);
  return ok({ saved: true });
}

function getConfig() {
  const rows = sheetToJSON(SHEET_NAME_CFG);
  const row = rows.find(r => r.key === 'main');
  if (!row) return null;
  try { return JSON.parse(row.value); } catch(e) { return null; }
}

// ── Build vote map: { pollId: { voterEmail: { position: candidateId } } }
function buildVoteMap() {
  const rows = sheetToJSON(SHEET_NAME_VOTES);
  const map = {};
  rows.forEach(r => {
    if (!r.pollId || !r.voterEmail) return;
    if (!map[r.pollId]) map[r.pollId] = {};
    if (!map[r.pollId][r.voterEmail]) map[r.pollId][r.voterEmail] = {};
    map[r.pollId][r.voterEmail][r.position] = r.candidateId;
  });
  return map;
}
